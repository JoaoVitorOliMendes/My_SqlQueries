CLEAR SCREEN;

--drop table login cascade constraints;
--drop table acesso;

create table login(
    cod_login number,
    login varchar2(30),
    senha varchar2(150),
    constraint cons_pk_login primary key(cod_login)
);

create table acesso(
    data_hora timestamp,
    cod_login number,
    constraint cons_fk_login foreign key(cod_login) references login(cod_login)
);

select * from login;
select * from acesso;