SET SERVEROUTPUT ON;
CLEAR SCREEN;

create or replace function fn_criptografia(senha varchar2, acrescimo number)
return varchar2
as
string1 varchar2(50);
string2 varchar2(50);
string3 varchar2(50);
asc2 varchar2(150);
begin
    for x in 1..length(senha) loop
        asc2 :=(ASCII(substr(senha, x, 1)) + acrescimo);
        if mod(x, 3) = 0
        then string1 := concat(string1, rpad('0', 3-length(asc2), '0')||asc2);
            elsif mod(x, 3) = 1
            then string2 := concat(string2, rpad('0', 3-length(asc2), '0')||asc2);
                elsif mod(x, 3) = 2
                then string3 := concat(string3, rpad('0', 3-length(asc2), '0')||asc2);
        end if;
    end loop;
    return string2||string3||string1;
end;
/

select fn_criptografia('COTEmig123', 3) from dual;