SET SERVEROUTPUT ON;
CLEAR SCREEN;

create or replace procedure pr_valida_login(loginPar varchar2, senhaPar varchar2)
as
codLoginEx number;
senhaLoginEX varchar2(150);
dateTime TIMESTAMP;
mlSec varchar2(10);
descripto varchar2(150);
begin
    dateTime := SYSTIMESTAMP;
    select (select login.cod_login from login where login.login = loginPar) into codLoginEx
    from dual;
    
    if codLoginEx is not null
    then 
        select (select to_char(acesso.data_hora, 'FF1') from acesso where acesso.cod_login = codLoginEx) into mlSec
        from dual;
        select (select login.senha from login where login.login = loginPar) into senhaLoginEX
        from dual;
        descripto := fn_descriptografia(senhaLoginEX, mlSec);
        if descripto = senhaPar
        then dbms_output.put_line('Acessou');
        update acesso set data_hora = dateTime where cod_login = codLoginEx;
        update login set senha = fn_criptografia(descripto, to_char(dateTime, 'FF1')) where cod_login = codLoginEx;
        else dbms_output.put_line('Nao acessou');
        end if;
    else dbms_output.put_line('Login nao existe');
    end if;
end;
/

call pr_valida_login('Jamir', 'COTEmig123');