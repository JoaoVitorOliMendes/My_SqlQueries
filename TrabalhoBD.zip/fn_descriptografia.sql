SET SERVEROUTPUT ON;
CLEAR SCREEN;

create or replace function fn_descriptografia(senhaCripto varchar2, acrescimo number)
return varchar2
as
senhaChar varchar2(150);
senhaFinal varchar2(150);
pulo number;
pulo2 number;
begin
    for x in 1..length(senhaCripto)/3 loop
        senhaChar := senhaChar||chr((substr(senhaCripto, (x*3)-2, 1)||substr(senhaCripto, (x*3)-1, 1)||substr(senhaCripto, x*3, 1) - acrescimo));
    end loop;
    
    pulo := floor(length(senhaChar)/3);
    if mod(length(senhaChar), 3) > 0
    then pulo := pulo + 1;
    end if;
    
    pulo2 := floor(length(senhaChar)/3);
    if mod(length(senhaChar), 3) > 1
    then pulo2 := pulo2 + 1;
    end if;
    
    for x in 1..pulo loop
        senhaFinal := senhaFinal||substr(senhaChar, x, 1)||substr(senhaChar, (x+pulo), 1)||substr(senhaChar, (x+pulo+pulo2), 1);
    end loop;
    
    if length(senhaFinal) <> length(senhaChar)
    then senhaFinal := substr(senhaFinal, 1, length(senhaChar));
    end if;
    
    return senhaFinal;
end;
/

select fn_descriptografia(fn_criptografia('COTEmig123', 3), 3) from dual;