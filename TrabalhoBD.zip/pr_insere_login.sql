SET SERVEROUTPUT ON;
CLEAR SCREEN;

--drop sequence;
--create sequence sq_login;

create or replace procedure pr_insere_login(codLogin number, loginPar varchar2, senha varchar2)
as
codLoginEx number;
loginEx varchar2(150);
senhaCripto varchar2(150);
dateTime TIMESTAMP;
begin
    dateTime := SYSTIMESTAMP;
    select (select login.cod_login from login where login.cod_login = codLogin) into codLoginEx
    from dual;
    select (select login.login from login where login.login = loginPar) into loginEx
    from dual;
    
    if codLoginEx is null and loginEx is null
    then senhaCripto := fn_criptografia(senha, to_char(dateTime, 'FF1'));
    insert into login(cod_login, login, senha) values (codLogin, loginPar, senhaCripto);
    insert into acesso(cod_login, data_hora) values (codLogin, dateTime);
    else dbms_output.put_line('Codigo de login ou login ja cadastrados');
    end if;
end;
/

call pr_insere_login(3, 'Jamir', 'COTEmig123');